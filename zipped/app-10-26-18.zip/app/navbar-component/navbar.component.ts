import { Component } from '@angular/core';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['../css/app.component.scss'],
})

export class NavbarComponent {}
