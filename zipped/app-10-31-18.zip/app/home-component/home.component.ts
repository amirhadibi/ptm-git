import {Component} from "@angular/core";
import { Router } from '@angular/router';

@Component({
    selector: 'home-page',
    templateUrl: './home.component.html',
    styleUrls: ['../css/app.component.scss'],
})
export class HomeComponent {}
