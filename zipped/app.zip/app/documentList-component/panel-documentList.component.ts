import { Component } from '@angular/core';

@Component({
  selector: 'panelDocList',
  templateUrl: './panel-documentList.component.html',
  styleUrls: ['../css/app.component.scss'],
})

export class PanelDocumentListComponent {}
