import { Component, EventEmitter, Output } from '@angular/core';
import { documentDetailsService } from '../documentDetails-component/document-details.service';

@Component({
    selector: 'buttons',
    templateUrl: './buttons.component.html',
})

export class ButtonsComponent {
    @Output() alertEvent = new EventEmitter();
    @Output() closeEvent = new EventEmitter();

    public gMessage: string='';  
    
    constructor(private _docDetailsService: documentDetailsService) {

    }
        
    showAlert(aMessage: string) {
        this.gMessage = aMessage;
        this.alertEvent.emit(null);
    }

    onClick() {
        //this.showAlert('This is a warning!');
        let vStatus = this._docDetailsService.getSelectedStatus();
        let vDocID = this._docDetailsService.selectedDocID;
        //console.log("vStatus: " + vStatus + vDocID);
        if (vStatus.trim() === 'TOPROCESS') {
            if (vDocID >= 15000000) this.showAlert('This is a XBRL document!!');
            else this.closeEvent.emit();
        } else {
            //this.showAlert('This should close dialog!!');
            this.closeEvent.emit(null);
        }

    }
}

    
