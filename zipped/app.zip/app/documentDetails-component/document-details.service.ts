import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'; // this is necessary
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import { AppSettings } from '../appsettings'

@Injectable()
export class documentDetailsService {

    public selectedTitle: BehaviorSubject<string> = new BehaviorSubject<string>("");
    public selectedFormCode: BehaviorSubject<string> = new BehaviorSubject<string>("01");
    public selectedColumnID: BehaviorSubject<number> = new BehaviorSubject<number>(1);
    public selectedStatus: BehaviorSubject<string> = new BehaviorSubject<string>("");
    public selectedDocID: number=0;
    public selectedFormDescription: string;
    public selectedCompanyName: string;
    public selectedReportTypeCode: string;
    public selectedChartCode: string;
    public selectedLiteral: string;
    public selectedCompNumber: number;
    public selectedOrderlink: number;
    public selectedMapcode: number;
    
    constructor(public http:Http) {
    }

    private setFormDescription(description: string) {
        this.selectedFormDescription = description;        
    }

    public getDocumentDetails() {
        ////console.log('arrived in service getDocumentDetails !!!');
        ////console.log('docDetailsService selectedDocumentID: ' + this.selectedDocID);
        ////console.log('docDetailsService selectedFormCode: ' + this.selectedFormCode.getValue());
        ////console.log('docDetailsService selectedColumnID: ' + this.selectedColumnID.getValue());

        const endpoint = AppSettings.DOC_DETAILS_API_ENDPOINT + 
            "?COMPNUMBER=" + this.selectedCompNumber + 
            "&CHARTCODE=" + this.selectedChartCode +
            //"&ACCOUNTTYPECODE="+ this.selectedReportTypeCode + //mySQL
            "&TYPECODE="+ this.selectedReportTypeCode +
            //"&DOCUMENTID=" + this.selectedDocID + //mySQL
            "&DOCID=" + this.selectedDocID +
            "&FORMCODE=" + this.selectedFormCode.getValue()

        if (this.selectedDocID > 0) {
            //console.log('DocDetails endpoint: ' + endpoint);
            return this.http.get(endpoint).map((res:Response) => res.json());
        }
        else {
            //console.log('docDetailsService selectedDocumentID <= 0 !!!');
            return null;
        }
    }

    public getColumnIDs() {
        //console.log('docDetailsService selectedDocumentID: ' + this.selectedDocID);
        //console.log('docDetailsService selectedFormCode: ' + this.selectedFormCode.getValue());
        //console.log('docDetailsService selectedColumnID: ' + this.selectedColumnID.getValue());

        const endpoint = 
        //AppSettings.COLUMNID_API_ENDPOINT + "?DOCUMENTID=" + this.selectedDocID + "&FORM=" + this.selectedFormCode.getValue(); //mySQL
        AppSettings.COLUMNID_API_ENDPOINT + "?DOCID=" + this.selectedDocID + "&FORMCODE=" + this.selectedFormCode.getValue();
        
        if (this.selectedDocID > 0) {
            //console.log('endpoint: ' + endpoint);
            return this.http.get(endpoint).map((res:Response) => res.json());
        }
        else {
            return null;
        }
    }

    /*
    // provides randomised data updates to some of the rows
    // only returns the changed data rows
    public byRowupdates(rowData: any) : any {
        return Observable.create((observer) => {
            const interval = setInterval(() => {
                let changes = [];

                // make some mock changes to the data
                this.makeSomePriceChanges(changes, rowData);
                //this.makeSomeVolumeChanges(changes);
                observer.next(changes);
            }, 1000);

            return () => clearInterval(interval);
        });
    }

    private makeSomePriceChanges(changes: any, rowData: any)  : any{
        // randomly update data for some rows
        //console.log('RowData: ' + rowData[0]);
        for (let i = 0; i < 10; i++) {
            const index = Math.floor(10 * Math.random());

            const currentRowData = rowData[index];

            // change by a value between -1 and 2 with one decimal place
            const move = (Math.floor(30 * Math.random())) / 10 - 1;
            const newValue = currentRowData.mid + move;
            currentRowData.mid = newValue;

            this.setBidAndAsk(currentRowData);

            changes.push(currentRowData);
        }
    }

    private setBidAndAsk(dataItem) : any {
        dataItem.AMOUNT1 = dataItem.AMOUNT1 * 0.98;
        dataItem.AMOUNT2 = dataItem.AMOUNT2 * 1.02;
    }
    */

    
    public getDocumentID(){
        return this.selectedDocID;
    }

    public getColumnID(){
        return this.selectedColumnID;
    }

    public getFormID(){
        return this.selectedFormCode;
    }

    public getCompanyName(){
        return this.selectedCompanyName;
    }

    public getCompNumber(){
        return this.selectedCompNumber;
    }

    public getOrderlink(){
        //console.log("docDetailsService.getOrderlink: " + this.selectedOrderlink)
        return this.selectedOrderlink;
    }

    public getMapcode(){
        //console.log("docDetailsService.getMapcode: " + this.selectedMapcode)
        return this.selectedMapcode;
    }

    public getReportTypeCode(){
        return this.selectedReportTypeCode;
    }

    public getChartCode(): any{        
        const endpoint = AppSettings.CHARTCODE_API_ENDPOINT + "?COMPNUMBER=" + this.selectedCompNumber;        
        if (this.selectedCompNumber > 0) {
            //console.log('endpoint: ' + endpoint);
            return this.http.get(endpoint).map((res:Response) => res.json());
        }
        else {
            return null;
        }        
    }

    public getStatusList(): any{
        const endpoint = AppSettings.STATUS_API_ENDPOINT;        
        //console.log('endpoint: ' + endpoint);
        return this.http.get(endpoint).map((res:Response) => res.json());
    }

    public getTitle() {
        return(this.selectedTitle);
    }

    public getSelectedStatus() {
        //console.log("In docDetails.service.ts getSelectedStatus: " + this.setSelectedStatus.getValue());
        return this.selectedStatus.getValue();
    }

    public getSelectedLiteral() {
        return this.selectedLiteral;
    }

    public setDocumentDetails(docID: number, formID: string, compName: string, 
            compNumber: number, columnID: number, type: string) {
        //console.log('setDocumentDetails type: ' + docID + "-" + formID+ "-" + type);
        if (docID) this.setDocID(docID);
        if (formID) this.setFormID(formID); 
        if (compName) this.setCompName(compName);
        if (compNumber) this.setCompNumber(compNumber);
        if (columnID) this.setColumnID(columnID);
        if (type) this.setReportTypeCode(type);   
        if (compNumber) this.setChartCode();  
        if (formID) this.setTitle(formID);   
    }

    public setDocID(docID: number) {
        this.selectedDocID = docID;        
    }

    public setFormID(formID: string) {
        this.selectedFormCode.next(formID);        
    }

    public setColumnID(columnID: number) {
        this.selectedColumnID.next(columnID);        
    }

    public setCompName(compName: string) {
        this.selectedCompanyName = compName;        
    }

    public setCompNumber(compNumber: number) {
        this.selectedCompNumber = compNumber;        
    }

    public setOrderlink(orderlink: number) {
        //console.log("docDetailsService.setOrderlink: " + orderlink)
        this.selectedOrderlink = orderlink;        
    }

    public setMapcode(mapcode: number) {
        //console.log("docDetailsService.setMapcode: " + mapcode)
        this.selectedMapcode = mapcode;        
    }

    public setReportTypeCode(type: string) {
        this.selectedReportTypeCode = type;        
    }

    public setSelectedLiteral(literal: string) {
        this.selectedLiteral = literal;        
    }

    public setChartCode() {
        let result: any[];
        let data: any[];
        //this.selectedChartCode = 'USA';   
        this.getChartCode().subscribe(
            // the first argument is a function which runs on success
            data => { result = data},
            // the second argument is a function which runs on error
            err => console.error(err),
            // the third argument is a function which runs on completion
            () => {
                this.selectedChartCode = result[0].CHARTCODE;
                //console.log("dd.setChartCode: " + this.selectedChartCode);       
            }
        );
        
}

    public setTitle(formID: string) {
        //console.log("setTitle TypeCode:" + this.selectedReportTypeCode);
        switch (formID) {
            case "01":
                this.setFormDescription('Balance Sheet');
            break;
            case "02":
                this.setFormDescription('Income Statement');
                break;
            case "05":
            this.setFormDescription('Cash Flow');
                break;
            default:
                this.setFormDescription('Balance Sheet');
            }
        this.selectedTitle.next(this.selectedDocID + ' : [' + 
        this.selectedCompNumber + '] ' + 
        this.selectedCompanyName + ' - ' + 
        this.selectedFormDescription + ' (' +      
        this.selectedReportTypeCode + ')'); 
    }

    public setSelectedStatus(newStatus: any) {
        this.selectedStatus.next(newStatus);
    }

}