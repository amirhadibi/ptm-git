import {Component} from '@angular/core';

/**
 * @title Button varieties
 */
@Component({
  selector: 'modal-button',
  templateUrl: 'modal-button.html',
})
export class ModalButton {}
