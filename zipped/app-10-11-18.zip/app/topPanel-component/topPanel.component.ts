import { Component } from '@angular/core';
import { MatDialog, MatInput, MatDialogConfig } from '@angular/material';
import { AppSettings } from '../appsettings';
import { PropertiesDialog } from '../properties-component/properties.component'
import { PropertiesService } from '../properties-component/properties.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'topPanel',
  templateUrl: './topPanel.component.html',
  styleUrls: ['../css/app.component.scss'],
})

export class TopPanelComponent {

  public documentHeaderList;
  public selectedPeriod: string = "";
  public selectedExtractedText: string = "";
  public selectedType: string = "";
  public selectedAuditor: string = "";
  public selectedMultiplier: string = "";
  public selectedCurrency: string = "";
  public selectedReportDate: string = "";
  public selectedConsolidated: string = "";
  public selectedFYEChange: string = "";
  public selectedPeriodFY: string = "";
  public selectedSourceTypeID: string = "";
  public selectedPrincipleTypeID: string = "";

  constructor(public dialog: MatDialog, private _propertiesService: PropertiesService,) {}

  ngOnInit() {
    //console.log('I am in ngOnInit()!');
    this.getDocumentHeaderList();
  } 

  public onChange(newValue: string) {
    let vString = newValue.split("::", 11);
    //console.log("newValue **** " + newValue);
    //console.log("vString **** " + vString);

    this.selectedPeriod = newValue;
    this.selectedExtractedText = vString[0];
    this.selectedType = vString[1];
    this.selectedAuditor = vString[2];
    this.selectedMultiplier = vString[3];
    this.selectedCurrency = vString[4];
    this.selectedReportDate = vString[5];
    this.selectedConsolidated = vString[6];
    this.selectedFYEChange = vString[7];
    this.selectedPeriodFY = vString[8];
    this.selectedSourceTypeID = vString[9];
    this.selectedPrincipleTypeID = vString[10];

    //console.log('topPanel.onChange()- Type: ' + this.selectedType);
    //console.log('topPanel.onChange()- Auditor: ' + this.selectedAuditor);
    //console.log('topPanel.onChange()- Multiplier: ' + this.selectedMultiplier);
    //console.log('topPanel.onChange()- Currency: ' + this.selectedCurrency);
    //console.log('topPanel.onChange()- ReportDate: ' + this.selectedReportDate);
    //console.log('topPanel.onChange()- Consolidated: ' + this.selectedConsolidated);
    //console.log('topPanel.onChange()- FYEChange: ' + this.selectedFYEChange);
    //console.log('topPanel.onChange()- selectedPeriodFY: ' + this.selectedPeriodFY);
    //console.log('topPanel.onChange()- selectedSourceTypeID: ' + this.selectedSourceTypeID);
    //console.log('topPanel.onChange()- selectedPrincipleTypeID: ' + this.selectedPrincipleTypeID);

    //if (this.selectedReportDate !== '0000-00-00') { //mySQL
    if (this.selectedReportDate !== 'null') {
      let re = /-/gi; 
      //console.log("selectedReportDate.length: " + this.selectedReportDate.length);
      let newDateString = this.selectedReportDate.replace(re, '/');
      //console.log("New Date: " + newDateString);
      //if (newDateString !== 'null') {
        this.selectedReportDate = (new Date(newDateString)).toISOString();
        this._propertiesService.setSelectedReportDate(this.selectedReportDate);
      //}
    } else {
      this.selectedReportDate = ((new Date()).toISOString());
      this._propertiesService.setSelectedReportDate(this.selectedReportDate);
      //this._propertiesService.setSelectedReportDate((new Date()).toISOString());
    }

    this._propertiesService.setSelectedExtractedText(this.selectedExtractedText);
    this._propertiesService.setSelectedType(this.selectedType);
    this._propertiesService.setSelectedAuditor(this.selectedAuditor);
    this._propertiesService.setSelectedMultiplier(this.selectedMultiplier);
    this._propertiesService.setSelectedCurrency(this.selectedCurrency);
    this._propertiesService.setSelectedReportDate(this.selectedReportDate);
    this._propertiesService.setSelectedConsolidated(this.selectedConsolidated);
    this._propertiesService.setSelectedFYEChange(this.selectedFYEChange);
    this._propertiesService.setSelectedPeriodFY(this.selectedPeriodFY);
    this._propertiesService.setSelectedSourceTypeID(this.selectedSourceTypeID);
    this._propertiesService.setSelectedPrincipleTypeID(this.selectedPrincipleTypeID);
    
  }

  // Opens Properties dialog. HTML and TS files are in properties-component:
  openDialog() {
    const settings: MatDialogConfig = {
      disableClose: true    
    }
    const dialogRef = this.dialog.open(PropertiesDialog, settings)
    dialogRef.afterClosed().subscribe(result => {
      console.log('*** *** *** '+ result);
      if (result === 'ok') {
        //this.savePropertiesData();
        let re = /-/gi; 
        console.log(
          'Save this data => ' + 
          "Auditor: " + this._propertiesService.getSelectedAuditor()
          + "  Currency: " + this._propertiesService.getSelectedCurrency() 
          + "  Multiplier: " + this._propertiesService.getSelectedMultiplier()
          + "  ReportType: " + this._propertiesService.getSelectedType()
          + "  PrincipleTypeID: " + this._propertiesService.getSelectedPrincipleTypeID()
          + "  SourceTypeID: " + this._propertiesService.getSelectedSourceTypeID()
          + "  Consolidated: " + this._propertiesService.getSelectedConsolidated() 
          + "  FYEChange: " + this._propertiesService.getSelectedFYEChange() 
          + "  PeriodFY: " + this._propertiesService.getSelectedPeriodFY() 
          + "  ReportDate: " + this._propertiesService.getSelectedReportDate().substr(0,10).replace(re, '/')
          );
    };
});
  }

  public getDocumentHeaderList() { 
    this._propertiesService.getDocumentHeaderList().subscribe(
        // the first argument is a function which runs on success
      data => { this.documentHeaderList = data;
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => {
          if (this.documentHeaderList.length > 0) {
            this.selectedPeriod = this.documentHeaderList[0].CAPTION + " "
              + this.documentHeaderList[0].REPORTDATE_TEXT + "::"
              + this.documentHeaderList[0].REPORTTYPE + "::"
              + this.documentHeaderList[0].AUDITOR + "::"
              + this.documentHeaderList[0].MULTIPLIER + "::"
              + this.documentHeaderList[0].CURRENCYCODE + "::"
              + this.documentHeaderList[0].REPORTDATE + "::"
              + this.documentHeaderList[0].CONSOLIDATED + "::"
              + this.documentHeaderList[0].FYECHANGE + "::"
              + this.documentHeaderList[0].PERIODFISCALYEAR + "::"
              + this.documentHeaderList[0].SOURCETYPEID + "::"
              + this.documentHeaderList[0].PRINCIPLETYPEID;
              
            this.selectedExtractedText = this.documentHeaderList[0].CAPTION + " "
                + this.documentHeaderList[0].REPORTDATE_TEXT;
            this._propertiesService.setSelectedExtractedText(this.selectedExtractedText);

            this.selectedType = this.documentHeaderList[0].REPORTTYPE;
            //console.log("selected-type=  " + this.selectedType);
            this._propertiesService.setSelectedType(this.selectedType);

            this.selectedAuditor = this.documentHeaderList[0].AUDITOR;
            //console.log("selected-auditor=  " + this.selectedAuditor);
            this._propertiesService.setSelectedAuditor(this.selectedAuditor);
            
            this.selectedMultiplier = this.documentHeaderList[0].MULTIPLIER;
            //console.log("selected-multiplier=  " + this.selectedMultiplier);
            this._propertiesService.setSelectedMultiplier(this.selectedMultiplier);

            this.selectedCurrency = this.documentHeaderList[0].CURRENCYCODE;
            //console.log("selected-curency=  " + this.selectedCurrency);
            this._propertiesService.setSelectedCurrency(this.selectedCurrency);
            
            this.selectedReportDate = this.documentHeaderList[0].REPORTDATE;                        
            //console.log("selected-reportdate=  " + this.selectedReportDate);
            if (this.selectedReportDate) {
              let re = /-/gi; 
              let newDateString = this.selectedReportDate.replace(re, '/');
              //console.log("newDateString: " + newDateString);
              this.selectedReportDate = (new Date(newDateString)).toISOString();
              this._propertiesService.setSelectedReportDate(this.selectedReportDate);
            } else {
              this._propertiesService.setSelectedReportDate((new Date()).toISOString());
            }

            this.selectedConsolidated = this.documentHeaderList[0].CONSOLIDATED;
            this._propertiesService.setSelectedConsolidated(this.selectedConsolidated);
            
            this.selectedFYEChange = this.documentHeaderList[0].FYECHANGE;
            this._propertiesService.setSelectedFYEChange(this.selectedFYEChange);
            
            this.selectedPeriodFY = this.documentHeaderList[0].PERIODFISCALYEAR;
            this._propertiesService.setSelectedPeriodFY(this.selectedPeriodFY);
            
            this.selectedSourceTypeID = this.documentHeaderList[0].SOURCETYPEID;
            this._propertiesService.setSelectedSourceTypeID(this.selectedSourceTypeID);
            
            this.selectedPrincipleTypeID = this.documentHeaderList[0].PRINCIPLETYPEID;
            this._propertiesService.setSelectedPrincipleTypeID(this.selectedPrincipleTypeID);
            
          } else {
            this._propertiesService.setSelectedExtractedText("");
          }
          //console.log('done with topPanel.getDocumentHeaderList() ... selectedPeriod is: ' + this.selectedPeriod)
        }
    );
  }


}
