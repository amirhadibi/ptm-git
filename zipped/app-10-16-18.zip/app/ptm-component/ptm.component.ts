import { Component } from '@angular/core';

@Component({
  selector: 'ptm-frontend',
  templateUrl: './ptm.component.html',
  styleUrls: ['../css/app.component.scss'],
})

export class PTMComponent {}
