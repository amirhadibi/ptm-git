import { Component } from '@angular/core';

@Component({
  selector: 'panelDocDetails',
  templateUrl: './panel-documentDetails.component.html',
  styleUrls: ['../css/app.component.scss'],
})

export class PanelDocumentDetailsComponent {}
